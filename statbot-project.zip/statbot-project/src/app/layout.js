// src/app/layout.js
export const metadata = {
  title: "StatBot — R Code Generator",
  description:
    "Upload your data, pick an analysis, describe what you need — get precise R code instantly.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body
        style={{
          margin: 0,
          padding: 0,
          background: "#0a0b0f",
          color: "#e2e4ea",
          fontFamily: "'Segoe UI', system-ui, sans-serif",
        }}
      >
        {children}
      </body>
    </html>
  );
}
